using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int damage =1;
}
