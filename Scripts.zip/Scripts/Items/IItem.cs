using UnityEngine;

public interface IItem
{
    public void Collect();

}
