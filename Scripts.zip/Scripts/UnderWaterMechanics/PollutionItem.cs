using UnityEngine;

public class PollutionItem : MonoBehaviour
{
    public string id = "bottle";
    public int points = 5;
    public AudioClip pickupSfx;
    public Sprite icon;
}