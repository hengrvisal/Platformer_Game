using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
public class PlayerInventory : MonoBehaviour
{
    private int Sapling = 0;
    private int Gem = 0;
    public void AddItem(PickupType type)
    {
        
    }
}
